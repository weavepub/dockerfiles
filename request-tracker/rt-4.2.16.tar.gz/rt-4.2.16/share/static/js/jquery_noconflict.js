/**
 * noConflict.js - Tell jQuery not to clobber $()
 */
jQuery.noConflict();
